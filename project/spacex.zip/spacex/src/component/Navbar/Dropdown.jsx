import React from "react";

const Dropdown = () => {
  return (
    <div className="dropdown">
      <select name="dropdown" id="dropdown">
        <option>Upcoming launches</option>
      </select>
    </div>
  );
};

export default Dropdown;
