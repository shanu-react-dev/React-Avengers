import FirstPage from "./component/Pages/FirstPage";
import "./index.css";
function App() {
  return (
    <div>
      <FirstPage />
    </div>
  );
}

export default App;
